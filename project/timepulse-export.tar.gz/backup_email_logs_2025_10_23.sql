/bin/bash: line 1: pg_dump: command not found
