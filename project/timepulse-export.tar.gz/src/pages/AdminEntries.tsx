import { useState, useEffect } from 'react';
import AdminLayout from '../components/Admin/AdminLayout';
import { FileText, Download, Filter, Calendar, Users, DollarSign, Eye, Search, X } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { exportToCSV, exportToElogica, exportStats, exportEmails, exportBibLabels, ExportEntry } from '../lib/excel-export';

export default function AdminEntries() {
  const [entries, setEntries] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterEvent, setFilterEvent] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [events, setEvents] = useState<any[]>([]);
  const [showExportMenu, setShowExportMenu] = useState(false);
  const [stats, setStats] = useState({
    total: 0,
    confirmed: 0,
    pending: 0,
    revenue: 0
  });

  useEffect(() => {
    loadEntries();
    loadEvents();
  }, []);

  async function loadEvents() {
    const { data } = await supabase
      .from('events')
      .select('id, name, slug')
      .order('created_at', { ascending: false });

    setEvents(data || []);
  }

  async function loadEntries() {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('registrations')
        .select(`
          *,
          events!inner(name, slug, city),
          races!inner(name),
          athletes(first_name, last_name, gender, birth_date, email, phone_mobile, nationality_code, license_number, club)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;

      setEntries(data || []);

      const total = data?.length || 0;
      const confirmed = data?.filter(e => e.payment_status === 'confirmed').length || 0;
      const pending = data?.filter(e => e.payment_status === 'pending').length || 0;
      const revenue = data?.filter(e => e.payment_status === 'confirmed').reduce((sum, e) => sum + (e.total_price || 0), 0) || 0;

      setStats({ total, confirmed, pending, revenue });
    } catch (error) {
      console.error('Error loading entries:', error);
    } finally {
      setLoading(false);
    }
  }

  function handleExportCSV() {
    const exportData: ExportEntry[] = filteredEntries.map(entry => ({
      bibNumber: entry.bib_number || 0,
      firstName: entry.athletes?.first_name || '',
      lastName: entry.athletes?.last_name || '',
      gender: entry.athletes?.gender || '',
      birthDate: entry.athletes?.birth_date || '',
      nationality: entry.athletes?.nationality_code || '',
      email: entry.athletes?.email || '',
      phone: entry.athletes?.phone_mobile || '',
      category: entry.category_label || '',
      raceName: entry.races?.name || '',
      price: entry.total_price || 0,
      status: entry.payment_status || '',
      registrationDate: entry.created_at || '',
      licenseNumber: entry.athletes?.license_number,
      club: entry.athletes?.club,
      emergencyContact: entry.emergency_contact_name,
      emergencyPhone: entry.emergency_contact_phone
    }));

    exportToCSV(exportData, `inscriptions-${new Date().toISOString().split('T')[0]}.csv`);
    setShowExportMenu(false);
  }

  function handleExportElogica() {
    const exportData: ExportEntry[] = filteredEntries
      .filter(entry => entry.payment_status === 'confirmed')
      .map(entry => ({
        bibNumber: entry.bib_number || 0,
        firstName: entry.athletes?.first_name || '',
        lastName: entry.athletes?.last_name || '',
        gender: entry.athletes?.gender || '',
        birthDate: entry.athletes?.birth_date || '',
        nationality: entry.athletes?.nationality_code || '',
        email: entry.athletes?.email || '',
        phone: entry.athletes?.phone_mobile || '',
        category: entry.category_label || '',
        raceName: entry.races?.name || '',
        price: entry.total_price || 0,
        status: entry.payment_status || '',
        registrationDate: entry.created_at || '',
        licenseNumber: entry.athletes?.license_number,
        club: entry.athletes?.club
      }));

    exportToElogica(exportData, `elogica-${new Date().toISOString().split('T')[0]}.csv`);
    setShowExportMenu(false);
  }

  function handleExportStats() {
    const confirmedEntries = filteredEntries.filter(e => e.payment_status === 'confirmed');
    const totalRevenue = confirmedEntries.reduce((sum, e) => sum + (e.total_price || 0), 0);

    const entriesByRace = Array.from(
      confirmedEntries.reduce((map, entry) => {
        const raceName = entry.races?.name || 'Non défini';
        map.set(raceName, (map.get(raceName) || 0) + 1);
        return map;
      }, new Map<string, number>())
    ).map(([raceName, count]) => ({ raceName, count }));

    const entriesByGender = Array.from(
      confirmedEntries.reduce((map, entry) => {
        const gender = entry.athletes?.gender || 'Non défini';
        map.set(gender, (map.get(gender) || 0) + 1);
        return map;
      }, new Map<string, number>())
    ).map(([gender, count]) => ({ gender, count }));

    const entriesByCategory = Array.from(
      confirmedEntries.reduce((map, entry) => {
        const category = entry.category_label || 'Non défini';
        map.set(category, (map.get(category) || 0) + 1);
        return map;
      }, new Map<string, number>())
    ).map(([category, count]) => ({ category, count }));

    exportStats({
      totalEntries: filteredEntries.length,
      confirmedEntries: confirmedEntries.length,
      pendingEntries: filteredEntries.filter(e => e.payment_status === 'pending').length,
      totalRevenue,
      entriesByRace,
      entriesByGender,
      entriesByCategory
    }, `stats-${new Date().toISOString().split('T')[0]}.csv`);

    setShowExportMenu(false);
  }

  function handleExportEmails() {
    const exportData: ExportEntry[] = filteredEntries
      .filter(entry => entry.payment_status === 'confirmed' && entry.athletes?.email)
      .map(entry => ({
        bibNumber: entry.bib_number || 0,
        firstName: entry.athletes?.first_name || '',
        lastName: entry.athletes?.last_name || '',
        gender: entry.athletes?.gender || '',
        birthDate: entry.athletes?.birth_date || '',
        nationality: entry.athletes?.nationality_code || '',
        email: entry.athletes?.email || '',
        phone: entry.athletes?.phone_mobile || '',
        category: entry.category_label || '',
        raceName: entry.races?.name || '',
        price: entry.total_price || 0,
        status: entry.payment_status || '',
        registrationDate: entry.created_at || ''
      }));

    exportEmails(exportData, `emails-${new Date().toISOString().split('T')[0]}.csv`);
    setShowExportMenu(false);
  }

  function handleExportBibLabels() {
    const exportData: ExportEntry[] = filteredEntries
      .filter(entry => entry.payment_status === 'confirmed')
      .map(entry => ({
        bibNumber: entry.bib_number || 0,
        firstName: entry.athletes?.first_name || '',
        lastName: entry.athletes?.last_name || '',
        gender: entry.athletes?.gender || '',
        birthDate: entry.athletes?.birth_date || '',
        nationality: entry.athletes?.nationality_code || '',
        email: entry.athletes?.email || '',
        phone: entry.athletes?.phone_mobile || '',
        category: entry.category_label || '',
        raceName: entry.races?.name || '',
        price: entry.total_price || 0,
        status: entry.payment_status || '',
        registrationDate: entry.created_at || ''
      }));

    exportBibLabels(exportData, `etiquettes-${new Date().toISOString().split('T')[0]}.csv`);
    setShowExportMenu(false);
  }

  const filteredEntries = entries.filter(entry => {
    const matchesSearch =
      entry.athletes?.first_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.athletes?.last_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.athletes?.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.bib_number?.toString().includes(searchTerm);

    const matchesEvent = filterEvent === 'all' || entry.event_id === filterEvent;
    const matchesStatus = filterStatus === 'all' || entry.payment_status === filterStatus;

    return matchesSearch && matchesEvent && matchesStatus;
  });

  return (
    <AdminLayout title="Inscriptions">
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Inscriptions</h1>
            <p className="text-gray-600 mt-1">Vue globale de toutes les inscriptions de la plateforme</p>
          </div>
          <div className="relative">
            <button
              onClick={() => setShowExportMenu(!showExportMenu)}
              className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-pink-600 to-purple-600 text-white rounded-lg hover:from-pink-700 hover:to-purple-700"
            >
              <Download className="w-5 h-5" />
              <span>Exporter</span>
            </button>

            {showExportMenu && (
              <div className="absolute right-0 mt-2 w-64 bg-white rounded-lg shadow-xl border border-gray-200 z-10">
                <div className="p-2">
                  <button
                    onClick={handleExportCSV}
                    className="w-full text-left px-4 py-2 hover:bg-gray-50 rounded-lg text-sm"
                  >
                    Excel complet (.csv)
                  </button>
                  <button
                    onClick={handleExportElogica}
                    className="w-full text-left px-4 py-2 hover:bg-gray-50 rounded-lg text-sm"
                  >
                    Format Elogica (chrono)
                  </button>
                  <button
                    onClick={handleExportStats}
                    className="w-full text-left px-4 py-2 hover:bg-gray-50 rounded-lg text-sm"
                  >
                    Statistiques (.csv)
                  </button>
                  <button
                    onClick={handleExportEmails}
                    className="w-full text-left px-4 py-2 hover:bg-gray-50 rounded-lg text-sm"
                  >
                    Liste emails
                  </button>
                  <button
                    onClick={handleExportBibLabels}
                    className="w-full text-left px-4 py-2 hover:bg-gray-50 rounded-lg text-sm"
                  >
                    Étiquettes dossards
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Total inscriptions</p>
                <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Confirmées</p>
                <p className="text-2xl font-bold text-gray-900">{stats.confirmed}</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <Calendar className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">En attente</p>
                <p className="text-2xl font-bold text-gray-900">{stats.pending}</p>
              </div>
              <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                <FileText className="w-6 h-6 text-yellow-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Revenus</p>
                <p className="text-2xl font-bold text-gray-900">{stats.revenue.toFixed(0)} €</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex flex-wrap gap-4 mb-6">
            <div className="flex-1 min-w-[200px] relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Rechercher (nom, email, dossard...)"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent"
              />
            </div>

            <select
              value={filterEvent}
              onChange={(e) => setFilterEvent(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent"
            >
              <option value="all">Tous les événements</option>
              {events.map(event => (
                <option key={event.id} value={event.id}>{event.name}</option>
              ))}
            </select>

            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent"
            >
              <option value="all">Tous les statuts</option>
              <option value="confirmed">Confirmées</option>
              <option value="pending">En attente</option>
              <option value="cancelled">Annulées</option>
            </select>

            {(searchTerm || filterEvent !== 'all' || filterStatus !== 'all') && (
              <button
                onClick={() => {
                  setSearchTerm('');
                  setFilterEvent('all');
                  setFilterStatus('all');
                }}
                className="px-4 py-2 text-gray-600 hover:text-gray-900 flex items-center gap-2"
              >
                <X className="w-4 h-4" />
                Réinitialiser
              </button>
            )}
          </div>

          {loading ? (
            <div className="text-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-pink-600 mx-auto"></div>
              <p className="mt-4 text-gray-600">Chargement des inscriptions...</p>
            </div>
          ) : filteredEntries.length === 0 ? (
            <div className="text-center py-12">
              <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">Aucune inscription trouvée</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Dossard</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Participant</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Événement</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Course</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Catégorie</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Prix</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Statut</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredEntries.map((entry) => (
                    <tr key={entry.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="font-bold text-gray-900">#{entry.bib_number || '-'}</span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">
                          {entry.athletes?.first_name} {entry.athletes?.last_name}
                        </div>
                        <div className="text-sm text-gray-500">{entry.athletes?.email}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{entry.events?.name}</div>
                        <div className="text-sm text-gray-500">{entry.events?.city}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {entry.races?.name}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                        {entry.category_label}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {entry.total_price?.toFixed(2)} €
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                          entry.payment_status === 'confirmed'
                            ? 'bg-green-100 text-green-800'
                            : entry.payment_status === 'pending'
                            ? 'bg-yellow-100 text-yellow-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {entry.payment_status === 'confirmed' ? 'Confirmée' :
                           entry.payment_status === 'pending' ? 'En attente' : 'Annulée'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {new Date(entry.created_at).toLocaleDateString('fr-FR')}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {filteredEntries.length > 0 && (
            <div className="mt-4 text-sm text-gray-600">
              Affichage de {filteredEntries.length} inscription{filteredEntries.length > 1 ? 's' : ''} sur {entries.length}
            </div>
          )}
        </div>
      </div>
    </AdminLayout>
  );
}
